# Turkish NLP

Very early version of the TurkishNLP. For now it has basically 2 main functions; Detecting Turkish Language and correcting typos in Turkish words.

## Dataset
Dataset was created by parsing and filtering a Turkish wikipedia dump. 

## Getting Started



### Downloading the data




### Usage




