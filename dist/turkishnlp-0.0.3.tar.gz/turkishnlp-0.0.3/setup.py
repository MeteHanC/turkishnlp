from distutils.core import setup
import setuptools
setup(
    name='turkishnlp',
    version='0.0.3',
    packages=['turkishnlp'],
    url='https://github.com/MeteHanC/turkishnlp',
    license='MIT',
    author='Metehan Cetinkaya',
    author_email='metehancet@gmail.com',
    description='A python script for Turkish NLP'
)